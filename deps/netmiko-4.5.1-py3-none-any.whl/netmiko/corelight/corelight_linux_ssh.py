from netmiko.linux.linux_ssh import LinuxSSH


class CorelightLinuxSSH(LinuxSSH):
    pass
