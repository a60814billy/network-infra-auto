from netmiko.rad.rad_etx import RadETXSSH
from netmiko.rad.rad_etx import RadETXTelnet

__all__ = ["RadETXSSH", "RadETXTelnet"]
