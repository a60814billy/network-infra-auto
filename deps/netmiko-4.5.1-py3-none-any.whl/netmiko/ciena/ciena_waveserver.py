from netmiko.ciena.ciena_saos import CienaSaosBase


class CienaWaveserverSSH(CienaSaosBase):
    pass
