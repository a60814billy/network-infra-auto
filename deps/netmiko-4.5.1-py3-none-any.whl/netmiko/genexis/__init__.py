from netmiko.genexis.genexis_solt33 import GenexisSOLT33Telnet

__all__ = ["GenexisSOLT33Telnet"]
