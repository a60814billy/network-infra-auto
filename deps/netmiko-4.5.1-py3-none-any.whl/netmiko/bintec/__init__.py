from netmiko.bintec.bintec_boss import BintecBossSSH
from netmiko.bintec.bintec_boss import BintecBossTelnet

__all__ = ["BintecBossSSH", "BintecBossTelnet"]
