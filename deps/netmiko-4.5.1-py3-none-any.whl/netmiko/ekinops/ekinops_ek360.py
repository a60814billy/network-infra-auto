from netmiko.oneaccess import OneaccessOneOSBase


class EkinopsEk360SSH(OneaccessOneOSBase):
    pass
