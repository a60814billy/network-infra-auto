from netmiko.linux.linux_ssh import LinuxSSH


class EdgecoreSonicSSH(LinuxSSH):
    pass
