
From https://github.com/python/cpython/blob/v3.12.4/Lib/telnetlib.py
Tag: v3.12.4

Licensed as per the included LICENSE file in this directory.

All contributions were made by the original contributor as documented
in the referenced github.com repository or as documented otherwise
by telnetlib's history.

Kirk Byers has made no code contributions to this library (well I 
removed one deprecation warning for PY3.13)

