from __future__ import unicode_literals
from netmiko.nec.nec_ix import NecIxSSH, NecIxTelnet

__all__ = ["NecIxSSH", "NecIxTelnet"]
