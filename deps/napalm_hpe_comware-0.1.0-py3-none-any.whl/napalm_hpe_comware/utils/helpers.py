# Copyright 2022 Eric Wu. All rights reserved.
#
# The contents of this file are licensed under the Apache License, Version 2.0
# (the "License"); you may not use this file except in compliance with the
# License. You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
# WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
# License for the specific language governing permissions and limitations under
# the License.

"""
Helper functions for HP Comware NAPALM driver.
"""

import re
import time
from datetime import datetime
from typing import Any, Callable, List, Dict, Union


def canonical_interface_name_comware(interface: str) -> str:
    """
    Normalize HP Comware interface names to a canonical format.

    Args:
        interface: Interface name from device output

    Returns:
        Canonical interface name

    Examples:
        GE1/0/1 -> GigabitEthernet1/0/1
        XGE1/0/1 -> Ten-GigabitEthernet1/0/1
        FortyGigE1/0/1 -> FortyGigE1/0/1
        HundredGigE1/0/1 -> HundredGigE1/0/1
        Vlan1 -> Vlan-interface1
    """
    if not interface:
        return interface

    # Dictionary mapping short forms to canonical forms
    interface_mappings = {
        r"^GE(\d+/\d+/\d+)$": r"GigabitEthernet\1",
        r"^Gi(\d+/\d+/\d+)$": r"GigabitEthernet\1",
        r"^GigE(\d+/\d+/\d+)$": r"GigabitEthernet\1",
        r"^XGE(\d+/\d+/\d+)$": r"Ten-GigabitEthernet\1",
        r"^TGE(\d+/\d+/\d+)$": r"Ten-GigabitEthernet\1",
        r"^Te(\d+/\d+/\d+)$": r"Ten-GigabitEthernet\1",
        r"^FE(\d+/\d+/\d+)$": r"FastEthernet\1",
        r"^Fa(\d+/\d+/\d+)$": r"FastEthernet\1",
        r"^Eth(\d+/\d+/\d+)$": r"Ethernet\1",
        r"^Et(\d+/\d+/\d+)$": r"Ethernet\1",
        r"^Vlan(\d+)$": r"Vlan-interface\1",
        r"^VLAN(\d+)$": r"Vlan-interface\1",
        r"^Loopback(\d+)$": r"LoopBack\1",
        r"^Lo(\d+)$": r"LoopBack\1",
        r"^NULL(\d+)$": r"NULL\1",
        r"^Null(\d+)$": r"NULL\1",
        r"^MGE0/(\d+/\d+/\d+)$": r"ManagementEthernet0/\1",
    }

    # Try to match and convert interface name
    for pattern, replacement in interface_mappings.items():
        if re.match(pattern, interface, re.IGNORECASE):
            return re.sub(pattern, replacement, interface, flags=re.IGNORECASE)

    # If no pattern matches, return original interface name
    return interface


def parse_time(uptime_str: str) -> int:
    """
    Parse HP Comware uptime string and convert to seconds.

    Args:
        uptime_str: Uptime string from device output

    Returns:
        Uptime in seconds, or -1 if parsing fails

    Examples:
        "1 week, 2 days, 3 hours, 4 minutes" -> seconds
        "2 days, 5 hours, 30 minutes" -> seconds
        "10 hours, 25 minutes" -> seconds
        "45 minutes" -> seconds
    """
    if not uptime_str or uptime_str.strip() == "":
        return -1

    try:
        # Initialize total seconds
        total_seconds = 0

        # Clean up the string
        uptime_str = uptime_str.strip().lower()

        # Define time unit patterns and their conversion to seconds
        time_patterns = [
            (r"(\d+)\s*weeks?", 7 * 24 * 3600),
            (r"(\d+)\s*days?", 24 * 3600),
            (r"(\d+)\s*hours?", 3600),
            (r"(\d+)\s*minutes?", 60),
            (r"(\d+)\s*seconds?", 1),
        ]

        # Extract time components
        for pattern, multiplier in time_patterns:
            matches = re.findall(pattern, uptime_str)
            if matches:
                total_seconds += int(matches[0]) * multiplier

        return total_seconds if total_seconds > 0 else -1

    except (ValueError, AttributeError, IndexError):
        return -1


def parse_null(value: Any, default: Any, parser_func: Callable = None) -> Any:
    """
    Parse a value that might be null/empty and apply optional parsing function.

    Args:
        value: Value to parse
        default: Default value to return if value is null/empty
        parser_func: Optional function to apply to non-null values

    Returns:
        Parsed value or default

    Examples:
        parse_null("100", -1, int) -> 100
        parse_null("", -1, int) -> -1
        parse_null(None, "unknown") -> "unknown"
        parse_null("aa:bb:cc:dd:ee:ff", "unknown", mac) -> normalized MAC
    """
    # Check if value is null, empty, or contains common "empty" indicators
    if (
        value is None
        or value == ""
        or str(value).strip() == ""
        or str(value).strip() == "-"
        or str(value).strip().lower() in ["n/a", "na", "none", "null", "unknown"]
    ):
        return default

    # If parser function is provided, apply it
    if parser_func is not None:
        try:
            return parser_func(value)
        except (ValueError, TypeError, AttributeError):
            return default

    return value


def strptime(time_str: str) -> float:
    """
    Parse time string and convert to timestamp (seconds since epoch).

    Args:
        time_str: Time string to parse

    Returns:
        Timestamp in seconds, or -1 if parsing fails

    Examples:
        "2023-01-01 12:00:00" -> timestamp
        "Jan 01 12:00:00" -> timestamp
    """
    if not time_str or time_str.strip() == "":
        return -1.0

    try:
        time_str = time_str.strip()

        # Common time formats used by HP Comware devices
        time_formats = [
            "%Y-%m-%d %H:%M:%S",
            "%Y/%m/%d %H:%M:%S",
            "%m/%d/%Y %H:%M:%S",
            "%d/%m/%Y %H:%M:%S",
            "%b %d %H:%M:%S",
            "%b %d %Y %H:%M:%S",
            "%d %b %Y %H:%M:%S",
            "%Y-%m-%d",
            "%m/%d/%Y",
            "%d/%m/%Y",
            "%b %d %Y",
            "%d %b %Y",
        ]

        # Try each format
        for fmt in time_formats:
            try:
                dt = datetime.strptime(time_str, fmt)
                # If year is not specified, assume current year
                if dt.year == 1900:
                    dt = dt.replace(year=datetime.now().year)
                return dt.timestamp()
            except ValueError:
                continue

        # If no format matches, return -1
        return -1.0

    except (ValueError, AttributeError, TypeError):
        return -1.0


def get_value_from_list_of_dict(
    dict_list: List[Dict], key: str, func: Callable
) -> Dict:
    """
    Get a dictionary from a list of dictionaries based on a key and comparison function.

    Args:
        dict_list: List of dictionaries to search
        key: Key to compare values on
        func: Function to apply for comparison (e.g., min, max)

    Returns:
        Dictionary that matches the criteria, or empty dict if not found

    Examples:
        get_value_from_list_of_dict([{"usage": 10}, {"usage": 5}], "usage", min)
        -> {"usage": 5}
    """
    if not dict_list or not isinstance(dict_list, list):
        return {}

    try:
        # Filter dictionaries that have the specified key
        valid_dicts = [d for d in dict_list if isinstance(d, dict) and key in d]

        if not valid_dicts:
            return {}

        # Find the dictionary with the min/max value for the specified key
        target_dict = func(valid_dicts, key=lambda x: x.get(key, 0))
        return target_dict

    except (ValueError, TypeError, KeyError):
        return {}
