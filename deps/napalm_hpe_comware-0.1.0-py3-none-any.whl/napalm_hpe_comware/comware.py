import re
import socket
import telnetlib
import tempfile
import uuid
import os

from netmiko import ConnectHandler, FileTransfer, InLineTransfer
from netmiko.hp import HPComwareFileTransfer
from napalm.base.base import NetworkDriver
from napalm.base.exceptions import (
    ReplaceConfigException,
    ConnectionClosedException,
    CommandErrorException,
)


class ComwareDriver(NetworkDriver):
    """NAPALM HPE Comware Handler."""

    def __init__(
        self, hostname, username, password, port=22, timeout=60, optional_args=None
    ):
        """NAPALM HPE Comware Handler."""
        if optional_args is None:
            optional_args = {}
        self.hostname = hostname
        self.username = username
        self.password = password
        self.timeout = timeout
        self.port = port

        self.transport = optional_args.get("transport", "ssh")

        # Retrieve file names
        self.candidate_cfg = optional_args.get("candidate_cfg", "candidate_config.txt")
        self.merge_cfg = optional_args.get("merge_cfg", "merge_config.txt")
        self.rollback_cfg = optional_args.get("rollback_cfg", "rollback_config.txt")
        self.inline_transfer = optional_args.get("inline_transfer", False)
        if self.transport == "telnet":
            # Telnet only supports inline_transfer
            self.inline_transfer = True

        # None will cause autodetection of dest_file_system
        self._dest_file_system = optional_args.get("dest_file_system", None)
        self.auto_rollback_on_error = optional_args.get("auto_rollback_on_error", True)

        # Netmiko possible arguments
        netmiko_argument_map = {
            "port": None,
            "secret": "",
            "verbose": False,
            "keepalive": 30,
            "global_delay_factor": 1,
            "use_keys": False,
            "key_file": None,
            "ssh_strict": False,
            "system_host_keys": False,
            "alt_host_keys": False,
            "alt_key_file": "",
            "ssh_config_file": None,
            "allow_agent": False,
        }

        # Build dict of any optional Netmiko args
        self.netmiko_optional_args = {}
        for k, v in netmiko_argument_map.items():
            try:
                self.netmiko_optional_args[k] = optional_args[k]
            except KeyError:
                pass

        default_port = {"ssh": 22, "telnet": 23}
        if self.port is None:
            self.port = optional_args.get("port", default_port[self.transport])

        self.device = None
        self.config_replace = False
        self.interface_map = {}

        self.profile = ["comware"]

    def open(self):
        """Open a connection to the device."""
        device_type = "hp_comware"
        if self.transport == "telnet":
            device_type = "hp_comware_telnet"
        self.device = ConnectHandler(
            device_type=device_type,
            host=self.hostname,
            username=self.username,
            password=self.password,
            **self.netmiko_optional_args,
        )
        # ensure in enable mode
        # self.device.enable()

    def close(self):
        """Close the connection to the device."""
        self.device.disconnect()

    def _send_command(self, command):
        """Wrapper for self.device.send.command().

        If command is a list will iterate through commands until valid command.
        """
        try:
            if isinstance(command, list):
                for cmd in command:
                    output = self.device.send_command(cmd)
                    if "% Invalid" not in output:
                        break
            else:
                output = self.device.send_command(command)
            return output
        except (socket.error, EOFError) as e:
            raise ConnectionClosedException(str(e))

    def is_alive(self):
        """Returns a flag with the state of the connection."""
        null = chr(0)
        if self.device is None:
            return {"is_alive": False}
        if self.transport == "telnet":
            try:
                # Try sending IAC + NOP (IAC is telnet way of sending command
                # IAC = Interpret as Command (it comes before the NOP)
                self.device.write_channel(telnetlib.IAC + telnetlib.NOP)
                return {"is_alive": True}
            except UnicodeDecodeError:
                # Netmiko logging bug (remove after Netmiko >= 1.4.3)
                return {"is_alive": True}
            except AttributeError:
                return {"is_alive": False}
        else:
            # SSH
            try:
                # Try sending ASCII null byte to maintain the connection alive
                self.device.write_channel(null)
                return {"is_alive": self.device.remote_conn.transport.is_active()}
            except (socket.error, EOFError):
                # If unable to send, we can tell for sure that the connection is unusable
                return {"is_alive": False}
        return {"is_alive": False}

    def get_lldp_neighbors(self):
        lldp = {}
        command = "display lldp neighbor-information verbose"
        output = self._send_command(command)

        # Check if router supports the command
        if "% Invalid input" in output:
            return {}

        for lldp_interfaces in re.split("\n\n", output):
            local_port = ""
            port = ""
            sysname = ""
            management = ""
            for lldp_entry in lldp_interfaces.splitlines():
                if "LLDP neighbor-information of port" in lldp_entry:
                    local_port = re.findall(r"([^\[\]]*)", lldp_entry)[2]
                    # lldp_detail = 'display lldp neighbor-information interface ' + local_port + ' verbose'
                    # output_detail = self._send_command(lldp_detail)

                elif "Port ID             :" in lldp_entry:
                    port = lldp_entry.split(" : ")[1]
                elif "System name         :" in lldp_entry:
                    sysname = lldp_entry.split(" : ")[1]
                elif "Management address                : " in lldp_entry:
                    ip = re.findall(r"[0-9]+(?:\.[0-9]+){3}", lldp_entry)
                    if ip != []:
                        management = ip[0]
                    if sysname == "":
                        sysname = management
            port = port.replace("Ten-GigabitEthernet", "XGE")
            port = port.replace("FortyGigE", "FGE")
            local_port = local_port.replace("Ten-GigabitEthernet", "XGE")
            local_port = local_port.replace("FortyGigE", "FGE")
            entry = {"hostname": sysname, "port": port}
            lldp.setdefault(local_port, [])
            lldp[local_port].append(entry)

        return lldp

    @staticmethod
    def parse_uptime(uptime_str):
        """
        Extract the uptime string from the given HPE Comware Device.

        Return the uptime in seconds as an integer
        """
        HOUR_SECONDS = 3600
        DAY_SECONDS = 24 * HOUR_SECONDS
        WEEK_SECONDS = 7 * DAY_SECONDS
        YEAR_SECONDS = 365 * DAY_SECONDS
        # Initialize to zero
        (years, weeks, days, hours, minutes) = (0, 0, 0, 0, 0)

        uptime_str = uptime_str.strip()
        time_list = uptime_str.split(",")
        for element in time_list:
            if re.search("year", element):
                years = int(element.split()[0])
            elif re.search("week", element):
                weeks = int(element.split()[0])
            elif re.search("day", element):
                days = int(element.split()[0])
            elif re.search("hour", element):
                hours = int(element.split()[0])
            elif re.search("minute", element):
                minutes = int(element.split()[0])

        uptime_sec = (
            (years * YEAR_SECONDS)
            + (weeks * WEEK_SECONDS)
            + (days * DAY_SECONDS)
            + (hours * 3600)
            + (minutes * 60)
        )
        return uptime_sec

    def get_facts(self):
        """Return a set of facts from the devices."""
        # default values.
        vendor = "Hewlett Packard Enterprise"
        uptime = -1
        serial_number, fqdn, os_version, hostname, domain_name = ("Unknown",) * 5

        # obtain output from device
        show_ver = self._send_command("display version")
        show_dev = self._send_command("display device manuinfo")
        show_current = self._send_command("display cur")
        show_ip_int_br = self._send_command("display ip interface brief")

        # uptime/serial_number/IOS version
        for line in show_ver.splitlines():
            if " uptime is " in line:
                model, uptime_str = line.split(" uptime is ")
                uptime = self.parse_uptime(uptime_str)
                model = model.strip()

            if "Boot image version" in line:
                _, os_version = line.split("Boot image version: ")
                os_version = os_version.strip()

        # Determine domain_name and fqdn
        for line in show_current.splitlines():
            if " sysname " in line:
                _, hostname = line.split(" sysname ")
                hostname = hostname.strip()

            if " domain default enable " in line:
                _, domain_name = line.split(" domain default enable ")
                domain_name = domain_name.strip()
                break
        if domain_name != "Unknown" and hostname != "Unknown":
            fqdn = "{}.{}".format(hostname, domain_name)

        for line in show_dev.splitlines():
            if "DEVICE_SERIAL_NUMBER" in line:
                _, serial = line.split("DEVICE_SERIAL_NUMBER:")
                if serial_number != "Unknown":
                    serial_number += " / " + serial.strip()
                else:
                    serial_number = serial.strip()

        # interface_list filter
        interface_list = []
        show_ip_int_br = show_ip_int_br.strip()
        for line in show_ip_int_br.splitlines():
            if "Interface " in line:
                continue
            interface = line.split()[0]
            interface_list.append(interface)

        return {
            "uptime": uptime,
            "vendor": vendor,
            "os_version": os_version,
            "serial_number": serial_number,
            "model": model,
            "hostname": hostname,
            "fqdn": fqdn,
            "interface_list": interface_list,
        }

    def get_environment(self):
        """
        Get environment facts.

        power and fan are currently not implemented
        cpu is using 1-minute average
        cpu hard-coded to cpu0 (i.e. only a single CPU)
        """
        environment = {}
        cpu_cmd = "display cpu-usage"
        mem_cmd = "display memory"
        temp_cmd = "display environment"

        output = self._send_command(cpu_cmd)
        environment.setdefault("cpu", {})
        cpu_id = 0
        for line in output.splitlines():
            if "in last 1 minute" in line:
                # CPU utilization for five seconds: 2%/0%; one minute: 2%; five minutes: 1%
                cpu_regex = r"^.*(\d+)%.*$"
                environment["cpu"][cpu_id] = {}
                environment["cpu"][cpu_id]["%usage"] = 0.0
                match = re.search(cpu_regex, line)
                environment["cpu"][cpu_id]["%usage"] = float(match.group(1))
                cpu_id += 1

        output = self._send_command(mem_cmd)
        proc_used_mem = 0
        proc_free_mem = 0
        for line in output.splitlines():
            if "Mem:" in line:
                proc_used_mem += int(line.split()[2], 10)
                proc_free_mem += int(line.split()[3], 10)
        environment.setdefault("memory", {})
        environment["memory"]["used_ram"] = proc_used_mem
        environment["memory"]["available_ram"] = proc_free_mem

        environment.setdefault("temperature", {})
        output = self._send_command(temp_cmd)

        for line in output.splitlines():
            if "Hotspot 1" in line:
                system_temp = float(line.split()[3])
                system_temp_alert = float(line.split()[5])
                system_temp_crit = float(line.split()[6])
                env_value = {
                    "is_alert": system_temp >= system_temp_alert,
                    "is_critical": system_temp >= system_temp_crit,
                    "temperature": system_temp,
                }
                environment["temperature"]["system"] = env_value

        # Initialize 'power' and 'fan' to default values (not implemented)
        environment.setdefault("power", {})
        environment["power"]["invalid"] = {
            "status": True,
            "output": -1.0,
            "capacity": -1.0,
        }
        environment.setdefault("fans", {})
        environment["fans"]["invalid"] = {"status": True}

        return environment

    def get_config(self, retrieve="all"):
        """Implementation of get_config for IOS.

        Returns the startup or/and running configuration as dictionary.
        The keys of the dictionary represent the type of configuration
        (startup or running). The candidate is always empty string,
        since IOS does not support candidate configuration.
        """

        configs = {
            "startup": "",
            "running": "",
            "candidate": "",
        }

        if retrieve in ("startup", "all"):
            command = "display saved-configuration"
            output = self._send_command(command)
            configs["startup"] = output

        if retrieve in ("running", "all"):
            command = "display current-configuration"
            output = self._send_command(command)
            configs["running"] = output

        return configs

    @staticmethod
    def _create_tmp_file(config):
        """Write temp file and for use with inline config and SCP."""
        tmp_dir = tempfile.gettempdir()
        rand_fname = str(uuid.uuid4())
        filename = os.path.join(tmp_dir, rand_fname)
        with open(filename, "wt") as fobj:
            fobj.write(config)
        return filename

    def _discover_file_system(self):
        try:
            return self.device._autodetect_fs()
        except Exception:
            msg = (
                "Netmiko _autodetect_fs failed (to workaround specify "
                "dest_file_system in optional_args.)"
            )
            raise CommandErrorException(msg)

    @property
    def dest_file_system(self):
        return "flash:"
        # The self.device check ensures napalm has an open connection
        # if self.device and self._dest_file_system is None:
        #    self._dest_file_system = self._discover_file_system()
        # return self._dest_file_system

    def _gen_full_path(self, filename, file_system=None):
        """Generate full file path on remote device."""
        if file_system is None:
            return "{}/{}".format(self.dest_file_system, filename)
        else:
            if ":" not in file_system:
                raise ValueError(
                    "Invalid file_system specified: {}".format(file_system)
                )
            return "{}/{}".format(file_system, filename)

    def _check_file_exists(self, cfg_file):
        """
        Check that the file exists on remote device using full path.

        cfg_file is full path i.e. flash:/file_name

        For example
        # dir flash:/candidate_config.cfg
          Directory of flash:
          0 -rw-        4877 Jan 04 2021 05:46:11   candidate_config.cfg
          514048 KB total (383792 KB free)


        return boolean
        """
        cmd = "dir {}".format(cfg_file)
        output = self._send_command(cmd)
        if "Error opening" in output:
            return False
        elif "The file or directory doesn't exist." in output:
            return False
        else:
            return True

    def _scp_file(self, source_file, dest_file, file_system):
        """
        SCP file to remote device.

        Return (status, msg)
        status = boolean
        msg = details on what happened
        """
        return self._xfer_file(
            source_file=source_file,
            dest_file=dest_file,
            file_system=file_system,
            TransferClass=HPComwareFileTransfer,
        )

    def _inline_tcl_xfer(
        self, source_file=None, source_config=None, dest_file=None, file_system=None
    ):
        """
        Use Netmiko InlineFileTransfer (TCL) to transfer file or config to remote device.

        Return (status, msg)
        status = boolean
        msg = details on what happened
        """
        if source_file:
            return self._xfer_file(
                source_file=source_file,
                dest_file=dest_file,
                file_system=file_system,
                TransferClass=InLineTransfer,
            )
        if source_config:
            return self._xfer_file(
                source_config=source_config,
                dest_file=dest_file,
                file_system=file_system,
                TransferClass=InLineTransfer,
            )
        raise ValueError("File source not specified for transfer.")

    def _xfer_file(
        self,
        source_file=None,
        source_config=None,
        dest_file=None,
        file_system=None,
        TransferClass=FileTransfer,
    ):
        """Transfer file to remote device.

        By default, this will use Secure Copy if self.inline_transfer is set, then will use
        Netmiko InlineTransfer method to transfer inline using either SSH or telnet (plus TCL
        onbox).

        Return (status, msg)
        status = boolean
        msg = details on what happened
        """
        if not source_file and not source_config:
            raise ValueError("File source not specified for transfer.")
        if not dest_file or not file_system:
            raise ValueError("Destination file or file system not specified.")

        if source_file:
            kwargs = dict(
                ssh_conn=self.device,
                source_file=source_file,
                dest_file=dest_file,
                direction="put",
                file_system=file_system,
            )
        elif source_config:
            kwargs = dict(
                ssh_conn=self.device,
                source_config=source_config,
                dest_file=dest_file,
                direction="put",
                file_system=file_system,
            )

        with TransferClass(**kwargs) as transfer:
            # Check if file already exists and has correct MD5
            if transfer.check_file_exists() and transfer.compare_md5():
                msg = "File already exists and has correct MD5: no SCP needed"
                return (True, msg)
            if not transfer.verify_space_available():
                msg = "Insufficient space available on remote device"
                return (False, msg)

            # Transfer file
            transfer.transfer_file()

            # Compares MD5 between local-remote files
            if transfer.verify_file():
                msg = "File successfully transferred to remote device"
                return (True, msg)
            else:
                msg = "File transfer to remote device failed"
                return (False, msg)

    def _load_candidate_wrapper(
        self, source_file=None, source_config=None, dest_file=None, file_system=None
    ):
        """
        Transfer file to remote device for either merge or replace operations

        Returns (return_status, msg)
        """
        return_status = False
        msg = ""
        if source_file and source_config:
            raise ValueError("Cannot simultaneously set source_file and source_config")

        if source_config:
            if self.inline_transfer:
                (return_status, msg) = self._inline_tcl_xfer(
                    source_config=source_config,
                    dest_file=dest_file,
                    file_system=file_system,
                )
            else:
                # Use SCP
                tmp_file = self._create_tmp_file(source_config)
                (return_status, msg) = self._scp_file(
                    source_file=tmp_file, dest_file=dest_file, file_system=file_system
                )
                if tmp_file and os.path.isfile(tmp_file):
                    os.remove(tmp_file)
        if source_file:
            if self.inline_transfer:
                (return_status, msg) = self._inline_tcl_xfer(
                    source_file=source_file,
                    dest_file=dest_file,
                    file_system=file_system,
                )
            else:
                (return_status, msg) = self._scp_file(
                    source_file=source_file,
                    dest_file=dest_file,
                    file_system=file_system,
                )
        if not return_status:
            if msg == "":
                msg = "Transfer to remote device failed"
        return (return_status, msg)

    def load_replace_candidate(self, filename=None, config=None):
        """
        SCP file to device filesystem, defaults to candidate_config.cfg.

        Return None or raise exception
        """
        self.config_replace = True

        # Use .cfg extension for HPE Comware
        candidate_file = self.candidate_cfg.replace(".txt", ".cfg")

        return_status, msg = self._load_candidate_wrapper(
            source_file=filename,
            source_config=config,
            dest_file=candidate_file,
            file_system=self.dest_file_system,
        )
        if not return_status:
            raise ReplaceConfigException(msg)

    def compare_config(self):
        """
        Compare current configuration with candidate configuration using HPE Comware command.

        Returns the diff output.
        """
        if self.config_replace:
            # Use .cfg extension for HPE Comware
            candidate_file = self.candidate_cfg.replace(".txt", ".cfg")
            cfg_file = self._gen_full_path(candidate_file)

            if not self._check_file_exists(cfg_file):
                return "Candidate config file does not exist"
            # HPE Comware command to show diff
            cmd = "displcuray diff current-configuration configfile {}".format(cfg_file)
            diff = self._send_command(cmd)

            # Filter out unwanted lines
            ignore_strings = [
                "--- Current configuration",
                "+++",
                "No differences found",
            ]

            new_list = []
            for line in diff.splitlines():
                for ignore in ignore_strings:
                    if ignore in line:
                        break
                else:  # nobreak
                    new_list.append(line)

            return "\n".join(new_list)

    def commit_config(self, message="", revert_in=None):
        """
        Commit the configuration changes using HPE Comware command.

        If replacement operation, perform 'configuration replace file' for the entire config.
        If merge operation, apply the configuration commands.
        """
        if message:
            raise NotImplementedError(
                "Commit message not implemented for this platform"
            )

        if revert_in is not None:
            raise NotImplementedError("Revert timer not implemented for this platform")

        if self.config_replace:
            # Replace operation
            candidate_file = self.candidate_cfg.replace(".txt", ".cfg")
            cfg_file = self._gen_full_path(candidate_file)

            if not self._check_file_exists(cfg_file):
                raise ReplaceConfigException("Candidate config file does not exist")

            # HPE Comware command to replace configuration
            cmd = "configuration replace file {}".format(cfg_file)

            # output = self._send_command(cmd)
            self.device.write_channel("system-view\n")
            self.device.write_channel(cmd + "\n")
            self.device.write_channel("Y\n")
            self.device.write_channel("\n")
            self.device.write_channel("Y\n")
            self.device.write_channel("end\n")

            # if "error" in output.lower() or "failed" in output.lower():
            #     msg = "Candidate config could not be applied\n{}".format(output)
            #     raise ReplaceConfigException(msg)

        # Save configuration to startup
        self.device.send_command("save")
